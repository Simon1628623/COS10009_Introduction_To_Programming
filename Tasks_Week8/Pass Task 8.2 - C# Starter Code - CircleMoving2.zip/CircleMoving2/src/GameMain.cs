using System;
using SwinGameSDK;
using SwinGameSDK.SwinGame;

namespace MyGame
{
    public class GameMain
    {
        public static void Main()
        {
            OpenGraphicsWindow("Circle Moving 2 - C#", 800, 600);
            ClearScreen(Color.White);
            RefreshScreen();
            Delay(5000);
        }
    }
}

